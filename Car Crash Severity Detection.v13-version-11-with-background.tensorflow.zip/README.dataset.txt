# Car Crash Severity Detection > Version 11 - with background
https://universe.roboflow.com/ansonlau1325-gmail-com/car-crash-severity-detection

Provided by a Roboflow user
License: CC BY 4.0

